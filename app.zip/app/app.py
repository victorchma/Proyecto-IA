# -*- coding: utf-8 -*-
"""
Front de predicción de ictus (Streamlit).
El usuario rellena los datos de un paciente -> la app llama al modelo ->
muestra la predicción y la probabilidad en pantalla.

Ejecuta:   streamlit run app.py
"""
import joblib
import numpy as np
import pandas as pd
import streamlit as st
from preprocesado import add_bmi_missing   # necesario para recargar el modelo

# ------------------------------------------------------------------
# 1. Cargar el modelo entrenado (una sola vez, en caché)
# ------------------------------------------------------------------
@st.cache_resource
def cargar_modelo():
    art = joblib.load("modelo_ictus.joblib")
    return art["modelo"], art["umbral"], art["recall_objetivo"]

modelo, UMBRAL, RECALL_OBJ = cargar_modelo()

# ------------------------------------------------------------------
# 2. Configuración y estilos de la página
# ------------------------------------------------------------------
st.set_page_config(page_title="Predicción de ictus", page_icon="🧠", layout="centered")
st.markdown("""
<style>
  .stApp { background: #f9f9f7; }
  h1 { color: #184f95; }
  .resultado { padding: 22px; border-radius: 12px; text-align: center; margin-top: 8px; }
  .riesgo-alto { background: #fdecec; border: 2px solid #d03b3b; }
  .riesgo-bajo { background: #eaf6ea; border: 2px solid #0ca30c; }
  .etiqueta { font-size: 15px; color: #52514e; margin-bottom: 4px; }
  .valor-alto { font-size: 30px; font-weight: 700; color: #d03b3b; }
  .valor-bajo { font-size: 30px; font-weight: 700; color: #0ca30c; }
</style>
""", unsafe_allow_html=True)

st.title("🧠 Predicción de riesgo de ictus")
st.caption("Introduce los datos del paciente y pulsa **Predecir**. "
           "El modelo devuelve la probabilidad de ictus y una alerta de cribado.")

# ------------------------------------------------------------------
# 3. Formulario con las 10 variables del dataset
# ------------------------------------------------------------------
with st.form("datos_paciente"):
    c1, c2 = st.columns(2)
    with c1:
        gender = st.selectbox("Sexo", ["Male", "Female"])
        age = st.slider("Edad", 0, 100, 55)
        hypertension = st.selectbox("¿Hipertensión?", ["No", "Sí"])
        heart_disease = st.selectbox("¿Cardiopatía?", ["No", "Sí"])
        ever_married = st.selectbox("¿Ha estado casado/a?", ["Yes", "No"])
    with c2:
        work_type = st.selectbox("Tipo de trabajo",
            ["Private", "Self-employed", "Govt_job", "children", "Never_worked"])
        residence = st.selectbox("Residencia", ["Urban", "Rural"])
        glucose = st.number_input("Glucosa media (mg/dL)", 40.0, 300.0, 100.0, step=0.5)
        bmi_desconocido = st.checkbox("BMI desconocido")
        bmi = st.number_input("BMI (índice de masa corporal)", 10.0, 100.0, 28.0,
                              step=0.1, disabled=bmi_desconocido)
        smoking = st.selectbox("Tabaquismo",
            ["never smoked", "formerly smoked", "smokes", "Unknown"])
    enviar = st.form_submit_button("🔎 Predecir", use_container_width=True)

# ------------------------------------------------------------------
# 4. Al enviar: construir el ejemplo, llamar al modelo y mostrar
# ------------------------------------------------------------------
if enviar:
    ejemplo = pd.DataFrame([{
        "gender": gender,
        "age": float(age),
        "hypertension": 1 if hypertension == "Sí" else 0,
        "heart_disease": 1 if heart_disease == "Sí" else 0,
        "ever_married": ever_married,
        "work_type": work_type,
        "Residence_type": residence,
        "avg_glucose_level": float(glucose),
        "bmi": np.nan if bmi_desconocido else float(bmi),
        "smoking_status": smoking,
    }])

    # El modelo devuelve la probabilidad; el umbral decide la alerta
    proba = float(modelo.predict_proba(ejemplo)[:, 1][0])
    alerta = proba >= UMBRAL

    st.divider()
    if alerta:
        st.markdown(f"""
        <div class="resultado riesgo-alto">
          <div class="etiqueta">Resultado del modelo</div>
          <div class="valor-alto">⚠️ RIESGO ALTO — revisar paciente</div>
        </div>""", unsafe_allow_html=True)
    else:
        st.markdown(f"""
        <div class="resultado riesgo-bajo">
          <div class="etiqueta">Resultado del modelo</div>
          <div class="valor-bajo">✅ RIESGO BAJO</div>
        </div>""", unsafe_allow_html=True)

    st.write("")
    m1, m2 = st.columns(2)
    m1.metric("Probabilidad estimada de ictus", f"{proba*100:.1f} %")
    m2.metric("Umbral de decisión", f"{UMBRAL*100:.1f} %",
              help=f"Ajustado para detectar ~{RECALL_OBJ:.0%} de los ictus reales.")
    st.progress(min(proba, 1.0))

    st.caption(
        "ℹ️ Es un modelo de **cribado**: prioriza no dejar escapar ictus, por lo que "
        "genera algunas falsas alarmas. No es un diagnóstico. Dataset de práctica; "
        "no apto para uso clínico real.")

# Barra lateral con info del modelo
with st.sidebar:
    st.header("Sobre el modelo")
    st.write(f"**Umbral de alerta:** {UMBRAL:.3f}")
    st.write(f"**Objetivo de detección:** {RECALL_OBJ:.0%} de los ictus")
    st.write("**Algoritmo:** regresión logística balanceada")
    st.write("El modelo se entrena en `entrenar_modelo.py` y se guarda en "
             "`modelo_ictus.joblib`, que esta app carga al arrancar.")
