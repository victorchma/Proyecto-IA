# -*- coding: utf-8 -*-
"""
Función de preprocesamiento compartida por el entrenamiento y la app.
Vive en su propio módulo para que el modelo guardado (.joblib) pueda
recargarse sin problemas desde cualquier script.
"""


def add_bmi_missing(d):
    """Añade la columna 'bmi_missing' (1 si el BMI falta) a partir del BMI crudo."""
    d = d.copy()
    d["bmi_missing"] = d["bmi"].isna().astype(int)
    return d
